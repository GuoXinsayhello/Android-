﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.Net;
using Control;
using System.Text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;



using System.Net.Sockets;

namespace WinUI
{
    public partial class Main : Form
    {
        SocketManager socketManager;
        OpenFileDialog openFileDialog;
        List<string> fileNames, safeFileNames;
        BackgroundWorker worker;
        String info = null;
        String addreno = null;
        String no = null;
        String addre = null;
        public void ssss()
        {
            int recv;
            byte[] data = new byte[1024];
            IPEndPoint ipep = new IPEndPoint(IPAddress.Any, 9999);
            EndPoint r = (EndPoint)(ipep);
            Socket newsock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            newsock.Bind(ipep);
            //MessageBox.Show(r.ToString());
            IPEndPoint sender1 = new IPEndPoint(IPAddress.Any, 0);
            EndPoint Remote = (EndPoint)(sender1);
            recv = newsock.ReceiveFrom(data, ref Remote);
           // MessageBox.Show(Remote.ToString());
            //MessageBox.Show(Encoding.ASCII.GetString(data, 0, recv));
           
            string welcome = "Welcome ! ";
            data = Encoding.ASCII.GetBytes(welcome);
            newsock.SendTo(data, data.Length, SocketFlags.None, Remote);
            while (true)
            {
                data = new byte[1024];
                recv = newsock.ReceiveFrom(data, ref Remote);
           String str=(Encoding.ASCII.GetString(data, 0, recv));

           Console.WriteLine(str);
           for (int i = 1; i < str.Length && (str[i] != '@' &&(str[i]!='-')); i++)
           {
               info = str.Substring(0, i+1);
               addreno = str.Substring(i + 2);
               
           }
           if (addreno[0] != '1')
           {

               for (int j = 1; j < addreno.Length && (addreno[j] != '@'); j++)
               {
                   no = addreno.Substring(0, j + 1);
                   addre = addreno.Substring(j + 2);

               }
           }
           else
           {
               no = " ";
               addre = addreno;
           }
           Console.WriteLine("str是："+str);
           Console.WriteLine("addreno是："+addreno);
           Console.WriteLine("addre是："+addre);
           Console.WriteLine("no是："+no);
   
                switch (info)
                {
                    case "video1.mp4":
                        //Console.WriteLine(addre);
                        ///MessageBox.Show("gotit!");
                        searchfile(@"d:\labsource", "video1.mp4", addre,no);
                            
                        break;
                    case "video2.mp4":
                        Console.WriteLine(addre);
                       // MessageBox.Show("gotit!");
                        searchfile(@"d:\labsource", "video2.mp4", addre,no);

                        break;
                    case "video3.mp4":
                        Console.WriteLine(addre);
                       // MessageBox.Show("gotit!");
                        searchfile(@"d:\labsource", "video3.mp4", addre,no);

                        break;
                    case "video4.mp4":
                        searchfile(@"d:\labsource", "video4.mp4", addre, no);
                        break;
                    case "video5.mp4":
                        searchfile(@"d:\labsource", "video5.mp4", addre, no);
                        break;




                }
                newsock.SendTo(data, recv, SocketFlags.None, Remote);
            }
        }



       

        public Main()
        {
            InitializeComponent();

            
        }
        private void Main_Load(object sender, EventArgs e)
        {

            openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            openFileDialog.FileOk += new CancelEventHandler(openFileDialog_FileOk);

            socketManager = new SocketManager();
            socketManager.SetState += this.SetState;
            int port = socketManager.CreateServerSocket();
            if (port > 0)
            {
                lblPort.Text = "本地监听端口：" + port;
            }

            fileNames = new List<string>();
            safeFileNames = new List<string>();
            this.GetLocalHostAddresses();

            worker = new BackgroundWorker();
            worker.DoWork += new DoWorkEventHandler(worker_DoWork);
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);


            //the following is added
            Thread thread1 = new Thread(ssss);
            thread1.ApartmentState = ApartmentState.STA;   //属性设置成单线程
            //thread1.Isbackground = true;
            thread1.Start();



        }


        //以下为添加的函数
       public void searchfile(String dirname, String filename,String addre,String no)
        {
           
            DirectoryInfo dir = new DirectoryInfo(dirname);
            FileInfo[] finfo = dir.GetFiles();
            string fname = string.Empty;
            for (int i = 0; i < finfo.Length; i++)
            {
                fname = finfo[i].Name;
                //判断文件是否包含查询名
                if (fname.IndexOf(filename) > -1 && (fname.IndexOf(no)<=-1))
                {
                    Console.WriteLine(finfo[i].FullName);
                    this.fileNames.Add(finfo[i].FullName);
                    this.safeFileNames.Add(finfo[i].Name);
                    this.SetFileListDataSource();
                    this.SetBtnEnable();
                   
                    worker.RunWorkerAsync();
                    Thread.Sleep(10000);
                   
                }
               
            }
        
        }






        public void worker_DoWork(object sender, DoWorkEventArgs e)
        {
           //IPAddress ip = IPAddress.Parse(txtIP.Text);
            IPAddress ip = IPAddress.Parse(addre);
            //int port = int.Parse(txtPort.Text);
            int port = 9999;
            //保存结果
            e.Result = socketManager.SendFile(this.fileNames, this.safeFileNames, ip, port);
        }
        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if ((bool)e.Result)
            {
                this.ClearAll();
            }
        }


        private void btnOpen_Click(object sender, EventArgs e)
        {
            openFileDialog.ShowDialog();
        }
        void openFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            this.fileNames.AddRange(openFileDialog.FileNames);
            this.safeFileNames.AddRange(openFileDialog.SafeFileNames);
            this.SetFileListDataSource();
        }
        private void btnRemove_Click(object sender, EventArgs e)
        {
            this.ClearAll();
        }
        private void ClearAll()
        {
            this.fileNames.Clear();
            this.safeFileNames.Clear();
            this.SetFileListDataSource();
        }
        private void SetFileListDataSource()
        {
            lbFileList.DataSource = new string[] { };
            lbFileList.DataSource = this.fileNames;
            this.SetBtnEnable();
        }
        private void SetBtnEnable()
        {
            if (this.lbFileList.Items.Count > 0)
            {
                btnOpen.Enabled = false;
                btnSend.Enabled = true;
            }
            else
            {
                btnOpen.Enabled = true;
                btnSend.Enabled = false;
            }
        }
        /// <summary>
        /// 发送文件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSend_Click(object sender, EventArgs e)
        {
            //开始后台发送文件
            worker.RunWorkerAsync();
        }

        private void GetLocalHostAddresses()
        {
            IPAddress[] ip = Dns.GetHostAddresses(Dns.GetHostName());
            if (ip.Length > 0)
            {
                lblLocalHost.Text = "本机IP:" + ip[0].ToString();
            }
            else
            {
                lblLocalHost.Text = "本机IP:未连接网络";
            }
        }
        /// <summary>
        /// 非创建控件所在的线程以外的线程中更改控件
        /// </summary>
        public delegate void SetStateEventHandler(TransmitState state);
        public void SetState(TransmitState state)
        {
            if (this.InvokeRequired)
            {
                SetStateEventHandler d = new SetStateEventHandler(this.SetState);
                this.Invoke(d, new object[] { state });
            }
            else
            {
                switch (state)
                {
                    case TransmitState.Receiving:
                        lblMsg.Text = "正在接收文件"; break;
                    case TransmitState.ReceiveCompleted:
                        lblMsg.Text = "文件接收完成，保存在D盘ReceiveFile文件夹下"; break;
                    case TransmitState.ReceiveError:
                        lblMsg.Text = "文件接收错误"; break;
                    case TransmitState.Sending:
                        lblMsg.Text = "正在发送文件"; break;
                    case TransmitState.SendCompleted:
                        lblMsg.Text = "文件发送完成"; break;
                    case TransmitState.SendError:
                        lblMsg.Text = "文件发送错误"; break;
                }
            }
        }
        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void lbFileList_SelectedIndexChanged(object sender, System.EventArgs e)
        {

        }
    }
}
