﻿using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading;

namespace Control
{
    public enum TransmitState
    {
        Sending, SendCompleted, SendError,
        Receiving, ReceiveCompleted, ReceiveError
    }
    public class SocketManager
    {
        public delegate void SetStateEventHandler(TransmitState s);
        public event SetStateEventHandler SetState;
        

        private int count = 1024;
        private string savePath = @"D:\Receive\";
        private Socket serverSocket;
       
        public SocketManager()
        {
            if (!Directory.Exists(this.savePath))
            {
                Directory.CreateDirectory(this.savePath);
            }
        }
        
        /// <summary>
        /// 建立监听,返回监听端口
        /// </summary>
        /// <returns>返回本机监听端口，绑定端口失败返回-1，应该不会吧</returns>
        public int CreateServerSocket()
        {
            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            int port = 9999;
            while (port > 9000)
            {
                try
                {
                    IPEndPoint localEP = new IPEndPoint(IPAddress.Any, port);
                    serverSocket.Bind(localEP);
                    serverSocket.Listen(100);
                    break;
                }
                catch
                {
                    port--;
                }
            }
            if (port == 9000)
                return -1;
            Thread thread = new Thread(new ThreadStart(ReceiveFile));
            thread.Start();
            return port;
        }
        /// <summary>
        /// 接收文件
        /// </summary>
        private void ReceiveFile()
        {
            try
            {
                while (true)
                {
                    string fileName = this.ReceiveFileName();
                    if (fileName.Length == 0)
                    {//文件名接收错误，跳过接收文件
                        this.State(TransmitState.ReceiveError);
                        continue;
                    }
                    Socket clientSocket = serverSocket.Accept();
                    FileStream fs = new FileStream(this.savePath + fileName, FileMode.CreateNew);
                    NetworkStream stream = new NetworkStream(clientSocket);
                    BufferedStream bf = new BufferedStream(stream);
                    byte[] array = new byte[count];
                    while (bf.Read(array, 0, count) != 0)
                    {
                        fs.Write(array, 0, count);
                    }
                    fs.Close();
                    bf.Close();
                    stream.Close();
                    clientSocket.Close();
                    this.State(TransmitState.ReceiveCompleted);
                }
            }
            catch
            {
                this.State(TransmitState.ReceiveError);
            }
        }
        /// <summary>
        /// 接收文件名
        /// </summary>
        /// <returns>接收的文件名，接收错误返回空字符串</returns>
        private string ReceiveFileName()
        {
            try
            {
                Socket socket = serverSocket.Accept();
                this.State(TransmitState.Receiving);
                NetworkStream stream = new NetworkStream(socket);
                StreamReader sr = new StreamReader(stream);
                string fileName = sr.ReadToEnd();
                sr.Close();
                stream.Close();
                socket.Close();
                return fileName;
            }
            catch
            {
                return "";
            }
        }
        /// <summary>
        /// 发送文件到目标
        /// </summary>
        /// <param name="fileNames">带路径文件名列表</param>
        /// <param name="safeFileNames">不带路径文件名列表</param>
        /// <param name="ip">目标ip</param>
        /// <param name="port">目标端口</param>
        /// <returns>返回是否发送文件成功</returns>
        public bool SendFile(List<string> fileNames, List<string> safeFileNames, IPAddress ip, int port)
        {
            if (fileNames.Count == 0 || safeFileNames.Count == 0)
                return false;
            try
            {
                this.State(TransmitState.Sending);
                for (int i = 0; i < fileNames.Count; i++)
                {
                    //发送文件名
                    if (!this.SendFileName(ip, port, Encoding.UTF8.GetBytes(safeFileNames[i])))
                    {
                        this.State(TransmitState.SendError);
                        return false;
                    }
                    //发送文件
                    FileStream fs = new FileStream(fileNames[i], FileMode.Open);
                    byte[] array = new byte[count];
                    Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    IPEndPoint address = new IPEndPoint(ip, port);
                    socket.Connect(address);
                    while (fs.Read(array, 0, count) != 0)
                    {
                        socket.Send(array, 0, count, SocketFlags.None);
                    }
                    socket.Close();
                    fs.Close();
                }
                this.State(TransmitState.SendCompleted);
                return true;
            }
            catch
            {
                this.State(TransmitState.SendError);
                return false;
            }
        }
        /// <summary>
        /// 发送文件名
        /// </summary>
        /// <param name="ip"></param>
        /// <param name="port"></param>
        /// <param name="data"></param>
        /// <returns>是否发送成功</returns>
        private bool SendFileName(IPAddress ip, int port, byte[] data)
        {
            try
            {
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint address = new IPEndPoint(ip, port);
                socket.Connect(address);
                int size = socket.Send(data);
                socket.Close();
                if (size > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
        private void State(TransmitState state)
        {
            if (SetState != null)
            {
                SetState(state);
            }
        }
    }
}
